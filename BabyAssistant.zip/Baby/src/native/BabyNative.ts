import { NativeModules, NativeEventEmitter } from 'react-native';
const M = NativeModules.BabyModule;
export const bus = new NativeEventEmitter(M);
// events: 'onCommand' {text}, 'onState' {state}, 'onWhatsApp' {key,sender,text}
export const Baby = {
  start: () => M.startService(),
  stop: () => M.stopService(),
  sleep: (on: boolean) => M.setSleep(on),
  pauseMic: (on: boolean) => M.pauseMic(on),          // mute recognizer while TTS speaks
  configure: (name: string, lang: string, sos: string[]) => M.configure(name, lang, sos),
  run: (action: string, args: object = {}): Promise<string> => M.run(action, JSON.stringify(args)),
  hasAccessibility: (): Promise<boolean> => M.hasAccessibility(),
  openAccessibilitySettings: () => M.openAccessibilitySettings(),
};
