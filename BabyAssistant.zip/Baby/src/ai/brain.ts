import { Settings } from '../store/settings';
const SYSTEM = (name: string) => `You are ${name}, a hands-free voice assistant on an Android phone. The user speaks Hindi, English, Punjabi, Marathi, Gujarati or Bengali. Reply in the user's language, short and speakable.
Return ONLY JSON: {"action":string,"args":object,"reply":string}.
Actions: wifi{on}, bluetooth{on}, mobile_data{on}, hotspot{on}, flashlight{on}, brightness{level:0-100}, open_settings{page?}, alarm{hour,minute,label}, sos{}, whatsapp_send{contact,message}, whatsapp_read{}, whatsapp_call{contact}, instagram_search{user}, instagram_comment{text}, play_music{query,app:"youtube"|"music"}, note_add{items:string[]}, read_screen{}, analyze_screen{question}, code{prompt}, sleep{}, chat{}.
For "code": put runnable single-file HTML (2D canvas or three.js from cdnjs) in args.html. Use action "chat" for plain answers.`;

export interface Plan { action: string; args: any; reply: string }

export async function think(s: Settings, text: string, imageB64?: string): Promise<Plan> {
  const content: any[] = [];
  if (imageB64) content.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageB64 } });
  content.push({ type: 'text', text });
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': s.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 1500, system: SYSTEM(s.name), messages: [{ role: 'user', content }] }),
  });
  const j = await r.json();
  const raw: string = (j.content?.[0]?.text ?? '{}').replace(/```json|```/g, '').trim();
  try { return JSON.parse(raw); } catch { return { action: 'chat', args: {}, reply: raw }; }
}
