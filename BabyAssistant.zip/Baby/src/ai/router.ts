import { Baby } from '../native/BabyNative';
import { Plan, think } from './brain';
import { Settings } from '../store/settings';

// Returns text to speak + optional HTML for the Dev Workspace panel
export async function execute(plan: Plan, s: Settings, spoken: string): Promise<{ say: string; html?: string }> {
  const { action, args = {}, reply } = plan;
  switch (action) {
    case 'sleep': Baby.sleep(true); return { say: reply };
    case 'code': return { say: reply, html: args.html };
    case 'chat': return { say: reply };
    case 'read_screen': {
      const t = await Baby.run('read_screen');
      return { say: (await think(s, `Summarise this screen aloud, briefly:\n${t}`)).reply };
    }
    case 'analyze_screen': {
      const img = await Baby.run('screenshot'); // base64 jpeg
      return { say: (await think(s, args.question || spoken, img)).reply };
    }
    default: {
      const out = await Baby.run(action, args);
      return { say: out && out !== 'ok' ? out : reply };
    }
  }
}
