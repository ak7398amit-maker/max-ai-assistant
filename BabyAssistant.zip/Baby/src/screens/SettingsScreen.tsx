import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, Switch, View, StyleSheet } from 'react-native';
import Tts from 'react-native-tts';
import { LANGUAGES } from '../i18n/voices';
import { Settings, saveSettings } from '../store/settings';
import { C } from '../theme';

export default function SettingsScreen({ settings, onSave, onBack }: { settings: Settings; onSave: (s: Settings) => void; onBack: () => void }) {
  const [s, setS] = useState(settings);
  const [voices, setVoices] = useState<any[]>([]);
  useEffect(() => { Tts.voices().then(v => setVoices(v.filter((x: any) => !x.notInstalled))); }, []);
  const langVoices = voices.filter(v => v.language?.replace('_', '-').startsWith(s.lang.slice(0, 2))).slice(0, 20);
  const set = (p: Partial<Settings>) => setS({ ...s, ...p });
  const save = async () => { await saveSettings(s); onSave(s); onBack(); };

  return (
    <ScrollView style={st.root} contentContainerStyle={{ padding: 22, paddingTop: 54 }}>
      <Text style={st.h}>Assistant name</Text>
      <TextInput style={st.in} value={s.name} onChangeText={name => set({ name })} placeholder="Baby" placeholderTextColor={C.dim} />
      <Text style={st.note}>Wake phrase becomes “Hey {s.name || 'Baby'}”.</Text>

      <Text style={st.h}>Language</Text>
      <View style={st.row}>{LANGUAGES.map(l => (
        <TouchableOpacity key={l.code} onPress={() => set({ lang: l.code, voiceId: undefined })} style={[st.chip, s.lang === l.code && st.on]}>
          <Text style={{ color: C.text }}>{l.label}</Text></TouchableOpacity>))}
      </View>

      <Text style={st.h}>Voice ({langVoices.length} installed)</Text>
      {langVoices.map(v => (
        <TouchableOpacity key={v.id} onPress={() => { set({ voiceId: v.id }); Tts.setDefaultVoice(v.id); Tts.speak(`Hey, I am ${s.name}`); }}
          style={[st.chip, { marginBottom: 6 }, s.voiceId === v.id && st.on]}>
          <Text style={{ color: C.text }}>{v.name}</Text></TouchableOpacity>))}
      {langVoices.length === 0 && <Text style={st.note}>No voices for this language. Install them in Android Settings → Text-to-speech.</Text>}

      <Text style={st.h}>Claude API key</Text>
      <TextInput style={st.in} value={s.apiKey} onChangeText={apiKey => set({ apiKey })} secureTextEntry autoCapitalize="none" placeholder="sk-ant-…" placeholderTextColor={C.dim} />

      <Text style={st.h}>Emergency SOS numbers</Text>
      <TextInput style={st.in} value={s.sosNumbers.join(',')} onChangeText={t => set({ sosNumbers: t.split(',').map(x => x.trim()).filter(Boolean) })} keyboardType="phone-pad" placeholder="+91…, +91…" placeholderTextColor={C.dim} />

      <View style={[st.row, { justifyContent: 'space-between', marginTop: 18 }]}>
        <Text style={{ color: C.text }}>Smart WhatsApp auto-reply</Text>
        <Switch value={s.autoReply} onValueChange={autoReply => set({ autoReply })} />
      </View>

      <TouchableOpacity style={st.save} onPress={save}><Text style={{ color: C.bg, fontWeight: '800' }}>Save</Text></TouchableOpacity>
      <TouchableOpacity onPress={onBack}><Text style={[st.note, { textAlign: 'center', marginTop: 16 }]}>Cancel</Text></TouchableOpacity>
    </ScrollView>
  );
}
const st = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  h: { color: C.core, fontSize: 14, fontWeight: '700', marginTop: 22, marginBottom: 8, letterSpacing: 1 },
  in: { borderWidth: 1, borderColor: C.line, color: C.text, padding: 12, borderRadius: 4, backgroundColor: C.panel },
  note: { color: C.dim, fontSize: 12, marginTop: 6 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center' },
  chip: { borderWidth: 1, borderColor: C.line, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 4 },
  on: { borderColor: C.core, backgroundColor: '#0A2A40' },
  save: { backgroundColor: C.core, padding: 14, alignItems: 'center', borderRadius: 4, marginTop: 28 },
});
