import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, PermissionsAndroid, Platform } from 'react-native';
import Tts from 'react-native-tts';
import ReactorCore from '../components/ReactorCore';
import StatusHUD from '../components/StatusHUD';
import CodePanel from '../components/CodePanel';
import { Baby, bus } from '../native/BabyNative';
import { think } from '../ai/brain';
import { execute } from '../ai/router';
import { Settings } from '../store/settings';
import { C, VState } from '../theme';

export default function HomeScreen({ settings, openSettings }: { settings: Settings; openSettings: () => void }) {
  const [state, setState] = useState<VState>('listening');
  const [heard, setHeard] = useState(''); const [said, setSaid] = useState('');
  const [html, setHtml] = useState<string | undefined>();
  const [a11y, setA11y] = useState(true);
  const S = useRef(settings); S.current = settings;

  const speak = useCallback(async (text: string) => {
    setSaid(text); setState('speaking'); Baby.pauseMic(true);
    await Tts.setDefaultLanguage(S.current.lang).catch(() => {});
    if (S.current.voiceId) await Tts.setDefaultVoice(S.current.voiceId).catch(() => {});
    Tts.speak(text);
  }, []);

  useEffect(() => {
    (async () => {
      if (Platform.OS === 'android') await PermissionsAndroid.requestMultiple([
        'android.permission.RECORD_AUDIO', 'android.permission.POST_NOTIFICATIONS', 'android.permission.ACCESS_FINE_LOCATION',
        'android.permission.SEND_SMS', 'android.permission.READ_CONTACTS', 'android.permission.CALL_PHONE', 'android.permission.CAMERA'] as any);
      const s = S.current; Baby.configure(s.name, s.lang, s.sosNumbers); Baby.start();
      setA11y(await Baby.hasAccessibility());
    })();
    const fin = Tts.addEventListener('tts-finish', () => { Baby.pauseMic(false); setState('listening'); });
    const st = bus.addListener('onState', (e: any) => setState(e.state));
    const cmd = bus.addListener('onCommand', async (e: any) => {
      setHeard(e.text); setState('thinking');
      try {
        const plan = await think(S.current, e.text);
        const out = await execute(plan, S.current, e.text);
        if (out.html) setHtml(out.html);
        await speak(out.say);
      } catch (err: any) { await speak('Kuch gadbad ho gayi: ' + (err?.message ?? 'error')); }
    });
    // Smart auto-reply to WhatsApp notifications
    const wa = bus.addListener('onWhatsApp', async (e: any) => {
      if (!S.current.autoReply) return;
      const p = await think(S.current, `Write a short, friendly WhatsApp reply (plain text only in "reply") to ${e.sender}: "${e.text}"`);
      Baby.run('whatsapp_reply', { key: e.key, text: p.reply });
    });
    return () => { fin.remove?.(); st.remove(); cmd.remove(); wa.remove(); };
  }, []);

  return (
    <View style={s.root}>
      <TouchableOpacity onPress={openSettings} style={s.gear}><Text style={{ color: C.core, fontSize: 22 }}>⚙</Text></TouchableOpacity>
      <View style={{ marginTop: 70 }}><ReactorCore state={state} /></View>
      <StatusHUD state={state} name={settings.name} heard={heard} said={said} />
      {!a11y && (
        <TouchableOpacity style={s.warn} onPress={Baby.openAccessibilitySettings}>
          <Text style={{ color: '#FFB347', textAlign: 'center' }}>Turn on {settings.name}'s Accessibility service to control WhatsApp, Instagram and settings</Text>
        </TouchableOpacity>)}
      <CodePanel html={html} onClose={() => setHtml(undefined)} />
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  gear: { position: 'absolute', right: 20, top: 44, zIndex: 2, padding: 8 },
  warn: { position: 'absolute', bottom: 30, left: 20, right: 20, padding: 14, borderWidth: 1, borderColor: '#FFB347', borderRadius: 4 },
});
