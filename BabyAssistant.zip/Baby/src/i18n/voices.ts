export const LANGUAGES = [
  { code: 'hi-IN', label: 'हिन्दी Hindi' },
  { code: 'en-IN', label: 'English (India)' },
  { code: 'en-US', label: 'English (US)' },
  { code: 'pa-IN', label: 'ਪੰਜਾਬੀ Punjabi' },
  { code: 'mr-IN', label: 'मराठी Marathi' },
  { code: 'gu-IN', label: 'ગુજરાતી Gujarati' },
  { code: 'bn-IN', label: 'বাংলা Bengali' },
];
