import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { C, VState } from '../theme';
const LABEL: Record<VState, string> = { sleeping: 'SLEEPING', listening: 'LISTENING', thinking: 'THINKING', speaking: 'SPEAKING' };
export default function StatusHUD({ state, name, heard, said }: { state: VState; name: string; heard: string; said: string }) {
  return (
    <View style={s.box}>
      <Text style={[s.title, { color: C.state[state] }]}>{name.toUpperCase()} · {LABEL[state]}</Text>
      <Text style={s.heard} numberOfLines={2}>{heard ? `“${heard}”` : state === 'sleeping' ? `Say “Hey ${name}” to wake` : `Say “Hey ${name}…”`}</Text>
      <Text style={s.said} numberOfLines={4}>{said}</Text>
    </View>
  );
}
const s = StyleSheet.create({
  box: { paddingHorizontal: 24, marginTop: 28, alignItems: 'center' },
  title: { fontSize: 15, letterSpacing: 4, fontWeight: '700' },
  heard: { color: C.dim, marginTop: 10, fontSize: 14, textAlign: 'center' },
  said: { color: C.text, marginTop: 10, fontSize: 16, textAlign: 'center', lineHeight: 22 },
});
