import React from 'react';
import { Modal, TouchableOpacity, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { C } from '../theme';
// Developer Workspace: renders AI-generated 2D/3D HTML snippets
export default function CodePanel({ html, onClose }: { html?: string; onClose: () => void }) {
  return (
    <Modal visible={!!html} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: C.bg }}>
        <WebView originWhitelist={['*']} source={{ html: html ?? '' }} javaScriptEnabled style={{ flex: 1, backgroundColor: C.bg }} />
        <TouchableOpacity onPress={onClose} style={{ padding: 18, backgroundColor: C.panel }}>
          <Text style={{ color: C.core, textAlign: 'center', fontWeight: '700' }}>Close workspace</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
}
