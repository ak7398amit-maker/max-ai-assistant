import React, { useEffect, useRef } from 'react';
import { Animated, Easing, View, StyleSheet } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';
import { C, VState } from '../theme';

const BARS = 28, SIZE = 280;

export default function ReactorCore({ state }: { state: VState }) {
  const spin = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const bars = useRef([...Array(BARS)].map(() => new Animated.Value(0.15))).current;
  const color = C.state[state];

  useEffect(() => {
    const speed = state === 'sleeping' ? 20000 : state === 'thinking' ? 1800 : 7000;
    spin.setValue(0);
    const a = Animated.loop(Animated.timing(spin, { toValue: 1, duration: speed, easing: Easing.linear, useNativeDriver: true }));
    a.start();
    const p = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: state === 'sleeping' ? 3000 : 900, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: state === 'sleeping' ? 3000 : 900, useNativeDriver: true })]));
    p.start();
    const live = state === 'listening' || state === 'speaking';
    const timer = setInterval(() => bars.forEach((b, i) =>
      Animated.timing(b, { toValue: live ? 0.2 + Math.random() * (state === 'speaking' ? 0.8 : 0.5) : 0.1, duration: 120, useNativeDriver: true }).start()), 130);
    return () => { a.stop(); p.stop(); clearInterval(timer); };
  }, [state]);

  const rot = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const rotRev = spin.interpolate({ inputRange: [0, 1], outputRange: ['360deg', '0deg'] });
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1.06] });

  return (
    <View style={styles.wrap}>
      <Animated.View style={[styles.abs, { transform: [{ rotate: rot }] }]}>
        <Svg width={SIZE} height={SIZE}>
          <Circle cx={140} cy={140} r={130} stroke={color} strokeWidth={2} strokeDasharray="6 10" fill="none" opacity={0.7} />
          <Circle cx={140} cy={140} r={112} stroke={color} strokeWidth={6} strokeDasharray="60 40" fill="none" opacity={0.35} />
        </Svg>
      </Animated.View>
      <Animated.View style={[styles.abs, { transform: [{ rotate: rotRev }] }]}>
        <Svg width={SIZE} height={SIZE}>
          <Circle cx={140} cy={140} r={92} stroke={color} strokeWidth={2} strokeDasharray="2 14" fill="none" />
        </Svg>
      </Animated.View>
      <Animated.View style={[styles.abs, { transform: [{ scale }] }]}>
        <Svg width={SIZE} height={SIZE}>
          <Defs><RadialGradient id="g" cx="50%" cy="50%" r="50%">
            <Stop offset="0" stopColor="#fff" stopOpacity="0.95" />
            <Stop offset="0.35" stopColor={color} stopOpacity="0.9" />
            <Stop offset="1" stopColor={color} stopOpacity="0" />
          </RadialGradient></Defs>
          <Circle cx={140} cy={140} r={64} fill="url(#g)" />
        </Svg>
      </Animated.View>
      <View style={[styles.abs, styles.barRow]}>
        {bars.map((b, i) => (
          <Animated.View key={i} style={{ width: 3, height: 60, marginHorizontal: 1.5, backgroundColor: color, borderRadius: 2, transform: [{ scaleY: b }] }} />
        ))}
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  wrap: { width: SIZE, height: SIZE, alignSelf: 'center' },
  abs: { position: 'absolute', width: SIZE, height: SIZE, alignItems: 'center', justifyContent: 'center' },
  barRow: { flexDirection: 'row', top: 110, height: 60 },
});
