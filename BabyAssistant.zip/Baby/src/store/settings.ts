import AsyncStorage from '@react-native-async-storage/async-storage';
import { Baby } from '../native/BabyNative';
export interface Settings {
  name: string; lang: string; voiceId?: string; apiKey: string;
  sosNumbers: string[]; autoReply: boolean;
}
export const DEFAULTS: Settings = { name: 'Baby', lang: 'hi-IN', apiKey: '', sosNumbers: [], autoReply: false };
const KEY = 'baby.settings';
export async function loadSettings(): Promise<Settings> {
  const raw = await AsyncStorage.getItem(KEY);
  return { ...DEFAULTS, ...(raw ? JSON.parse(raw) : {}) };
}
export async function saveSettings(s: Settings) {
  await AsyncStorage.setItem(KEY, JSON.stringify(s));
  Baby.configure(s.name, s.lang, s.sosNumbers); // native service re-reads wake word + language
}
