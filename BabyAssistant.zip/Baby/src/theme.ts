export const C = {
  bg: '#030A12', panel: '#07182A', line: '#0E3A5C',
  core: '#3DF0FF', text: '#CFF7FF', dim: '#5E8CA3',
  state: { sleeping: '#335B73', listening: '#3DF0FF', thinking: '#FFB347', speaking: '#FF4D4D' },
};
export type VState = 'sleeping' | 'listening' | 'thinking' | 'speaking';
