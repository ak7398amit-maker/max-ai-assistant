import re, pathlib
A = pathlib.Path('BabyAssistant/android/app/src/main')
snip = pathlib.Path('android/app/src/main/AndroidManifest.snippet.xml').read_text()
perms, services = snip.split('<!-- inside <application> -->')
perms = '\n'.join(l for l in perms.splitlines() if 'permission.INTERNET' not in l and not l.strip().startswith('<!--'))
m = (A / 'AndroidManifest.xml').read_text()
m = m.replace('<application', perms + '\n<application', 1).replace('</application>', services + '\n</application>', 1)
(A / 'AndroidManifest.xml').write_text(m)
s = A / 'res/values/strings.xml'
s.write_text(s.read_text().replace('</resources>', '<string name="a11y_desc">Lets the assistant control apps by voice</string></resources>'))
p = A / 'java/com/baby/assistant/MainApplication.kt'
t = p.read_text().replace('// add(MyReactNativePackage())', 'add(com.baby.assistant.BabyPackage())')
p.write_text(t)
print('patched')
