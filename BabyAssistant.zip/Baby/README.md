# Baby – Hands-free AI Voice Assistant (React Native + Android native)

## Setup
1. `npx @react-native-community/cli init BabyAssistant --version 0.74.5`, then copy `App.tsx`, `index.js`, `src/` over it and merge `package.json` deps. `npm i`.
2. Copy `android/app/src/main/java/com/baby/assistant/*.kt` into your project (set your package name if different) and `res/xml/accessibility_config.xml`.
3. Add `<string name="a11y_desc">Lets the assistant control apps by voice</string>` to `res/values/strings.xml`.
4. Merge `AndroidManifest.snippet.xml` into your manifest.
5. In `MainApplication`, add `add(BabyPackage())` to `getPackages()`.
6. Run, then grant: microphone, notifications, location, SMS, contacts; enable **Accessibility** and **Notification access** for the app, and **Modify system settings** (brightness).
7. Settings screen → paste Claude API key, pick language/voice, add SOS numbers.

## Know the limits
- Wi-Fi / Bluetooth / mobile data / hotspot cannot be toggled by regular apps on Android 10+. Baby opens the settings screen and the Accessibility service flips the switch (works, but is UI-dependent).
- Wake word uses Android SpeechRecognizer (no key needed, but uses battery and may beep on some devices). For true low-power always-on detection swap the loop in `WakeWordService` for Picovoice Porcupine with a custom "Hey Baby" keyword.
- Sleep mode listens in short windows every ~6 s for the wake phrase only; it does not fully stop the mic.
- WhatsApp/Instagram automation depends on app UI labels and may break after app updates; use for your own account only and respect each service's terms.
- Claude API key is stored on-device; for a shipping app, route calls through your own backend.
