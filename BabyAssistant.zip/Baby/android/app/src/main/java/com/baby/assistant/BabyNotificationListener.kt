package com.baby.assistant

import android.app.*
import android.content.*
import android.os.Bundle
import android.service.notification.*

/** Captures WhatsApp notifications → JS (smart reply) → answers through the notification's RemoteInput. */
class BabyNotificationListener : NotificationListenerService() {
    companion object {
        private val pending = HashMap<String, Notification.Action>()
        fun reply(c: Context, key: String, text: String) {
            val a = pending[key] ?: return; val ri = a.remoteInputs?.firstOrNull() ?: return
            val b = Bundle().apply { putCharSequence(ri.resultKey, text) }
            val i = Intent(); RemoteInput.addResultsToIntent(a.remoteInputs, i, b); a.actionIntent.send(c, 0, i)
        }
    }
    override fun onNotificationPosted(s: StatusBarNotification) {
        if (s.packageName != "com.whatsapp") return
        val n = s.notification; if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        pending[s.key] = act
        BabyBus.emit?.invoke("onWhatsApp", mapOf("key" to s.key,
            "sender" to (n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""),
            "text" to (n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "")))
    }
}
