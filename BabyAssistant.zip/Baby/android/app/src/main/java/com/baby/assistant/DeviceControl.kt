package com.baby.assistant

import android.app.SearchManager
import android.content.*
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.*
import android.telephony.SmsManager
import org.json.JSONObject

object DeviceControl {
    private fun Context.go(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    /** Android 10+ blocks apps from toggling Wi-Fi/data/hotspot/Bluetooth directly. We open the right
     *  settings screen and let the Accessibility service flip the switch. */
    private fun toggleViaSettings(c: Context, action: String, on: Boolean) {
        c.go(Intent(action))
        Handler(Looper.getMainLooper()).postDelayed({ BabyAccessibilityService.instance?.flipFirstSwitch(on) }, 900)
    }

    fun run(c: Context, action: String, a: JSONObject): String {
        when (action) {
            "wifi" -> toggleViaSettings(c, Settings.ACTION_WIFI_SETTINGS, a.optBoolean("on"))
            "bluetooth" -> toggleViaSettings(c, Settings.ACTION_BLUETOOTH_SETTINGS, a.optBoolean("on"))
            "mobile_data" -> toggleViaSettings(c, Settings.ACTION_DATA_ROAMING_SETTINGS, a.optBoolean("on"))
            "hotspot" -> toggleViaSettings(c, "android.settings.TETHER_SETTINGS", a.optBoolean("on"))
            "flashlight" -> { val cm = c.getSystemService(CameraManager::class.java); cm.setTorchMode(cm.cameraIdList[0], a.optBoolean("on")) }
            "brightness" -> {
                if (!Settings.System.canWrite(c)) { c.go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); return "Pehle Modify system settings permission dijiye" }
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (a.optInt("level", 50) * 255 / 100))
            }
            "open_settings" -> c.go(Intent(Settings.ACTION_SETTINGS))
            "alarm" -> c.go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "sos" -> sos(c)
            "play_music" -> {
                val q = a.optString("query"); val pkg = if (a.optString("app") == "music") "com.google.android.apps.youtube.music" else "com.google.android.youtube"
                c.go(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).setPackage(pkg)
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*").putExtra(SearchManager.QUERY, q))
            }
            "note_add" -> {
                val items = a.optJSONArray("items"); val sp = c.getSharedPreferences("notes", Context.MODE_PRIVATE)
                val cur = sp.getString("list", "") ?: ""
                val add = (0 until (items?.length() ?: 0)).joinToString("\n") { "• " + items!!.getString(it) }
                sp.edit().putString("list", if (cur.isEmpty()) add else "$cur\n$add").apply()
                c.go(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sp.getString("list", "")).let { Intent.createChooser(it, "Notes") })
            }
            "whatsapp_send" -> BabyAccessibilityService.instance?.whatsappSend(c, a.optString("contact"), a.optString("message")) ?: return needA11y()
            "whatsapp_call" -> BabyAccessibilityService.instance?.whatsappCall(c, a.optString("contact")) ?: return needA11y()
            "whatsapp_read" -> { c.packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { c.go(it) }
                Thread.sleep(1500); return BabyAccessibilityService.instance?.screenText() ?: needA11y() }
            "whatsapp_reply" -> BabyNotificationListener.reply(c, a.optString("key"), a.optString("text"))
            "instagram_search" -> c.go(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/${a.optString("user")}")).setPackage("com.instagram.android"))
            "instagram_comment" -> BabyAccessibilityService.instance?.instagramComment(a.optString("text")) ?: return needA11y()
            "read_screen" -> return BabyAccessibilityService.instance?.screenText() ?: needA11y()
        }
        return "ok"
    }
    private fun needA11y() = "Accessibility service on kijiye"

    @Suppress("MissingPermission")
    private fun sos(c: Context) {
        val lm = c.getSystemService(LocationManager::class.java)
        val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        val link = loc?.let { "https://maps.google.com/?q=${it.latitude},${it.longitude}" } ?: "location unavailable"
        val nums = c.getSharedPreferences("baby", Context.MODE_PRIVATE).getString("sos", "")!!.split(",").filter { it.isNotBlank() }
        val sms = c.getSystemService(SmsManager::class.java)
        nums.forEach { sms.sendTextMessage(it, null, "EMERGENCY! I need help. My location: $link", null, null) }
        nums.firstOrNull()?.let { c.go(Intent(Intent.ACTION_CALL, Uri.parse("tel:$it"))) }
    }
}
