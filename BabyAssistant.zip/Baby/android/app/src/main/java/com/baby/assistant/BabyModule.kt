package com.baby.assistant

import android.content.*
import android.provider.Settings
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.ReactPackage
import com.facebook.react.uimanager.ViewManager
import org.json.JSONObject

class BabyModule(private val ctx: ReactApplicationContext) : ReactContextBaseJavaModule(ctx) {
    override fun getName() = "BabyModule"
    init { BabyBus.emit = { ev, m ->
        val map = Arguments.createMap().apply { m.forEach { (k, v) -> putString(k, v) } }
        ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(ev, map) } }

    @ReactMethod fun addListener(n: String) {}
    @ReactMethod fun removeListeners(c: Int) {}
    @ReactMethod fun startService() { ctx.startForegroundService(Intent(ctx, WakeWordService::class.java)) }
    @ReactMethod fun stopService() { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }
    @ReactMethod fun setSleep(on: Boolean) { WakeWordService.instance?.setSleep(on) }
    @ReactMethod fun pauseMic(on: Boolean) { WakeWordService.micPaused = on }
    @ReactMethod fun configure(name: String, lang: String, sos: ReadableArray) {
        ctx.getSharedPreferences("baby", Context.MODE_PRIVATE).edit().putString("name", name).putString("lang", lang)
            .putString("sos", (0 until sos.size()).joinToString(",") { sos.getString(it)!! }).apply()
    }
    @ReactMethod fun hasAccessibility(p: Promise) { p.resolve(BabyAccessibilityService.instance != null) }
    @ReactMethod fun openAccessibilitySettings() { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    @ReactMethod fun run(action: String, json: String, p: Promise) {
        Thread {
            try {
                if (action == "screenshot") {
                    val s = BabyAccessibilityService.instance ?: return@Thread p.reject("a11y", "Accessibility off")
                    s.screenshot { p.resolve(it ?: "") }
                } else p.resolve(DeviceControl.run(ctx, action, JSONObject(json)))
            } catch (e: Exception) { p.reject("err", e.message) }
        }.start()
    }
}

class BabyPackage : ReactPackage {
    override fun createNativeModules(c: ReactApplicationContext): List<NativeModule> = listOf(BabyModule(c))
    override fun createViewManagers(c: ReactApplicationContext): List<ViewManager<*, *>> = emptyList()
}
