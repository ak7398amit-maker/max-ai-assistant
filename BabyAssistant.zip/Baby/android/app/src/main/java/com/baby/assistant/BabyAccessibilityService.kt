package com.baby.assistant

import android.accessibilityservice.AccessibilityService
import android.content.*
import android.graphics.Bitmap
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.util.Base64
import android.view.Display
import android.view.accessibility.*
import java.io.ByteArrayOutputStream

class BabyAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BabyAccessibilityService? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- helpers ----------
    fun screenText(): String { val sb = StringBuilder(); fun walk(n: AccessibilityNodeInfo?) {
            n ?: return; n.text?.let { sb.append(it).append('\n') }; n.contentDescription?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow); return sb.toString().take(6000) }

    private fun find(pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        fun walk(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? { n ?: return null
            if (pred(n)) return n; for (i in 0 until n.childCount) walk(n.getChild(i))?.let { return it }; return null }
        return walk(rootInActiveWindow)
    }
    private fun click(n: AccessibilityNodeInfo?) { var x = n; while (x != null && !x.isClickable) x = x.parent; x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
    private fun clickDesc(d: String) = click(find { it.contentDescription?.toString()?.contains(d, true) == true })
    private fun clickId(id: String) = click(find { it.viewIdResourceName == id })
    private fun type(text: String) { find { it.isEditable }?.let {
        it.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }) } }
    private fun later(ms: Long, f: () -> Unit) = h.postDelayed(f, ms)

    // ---------- settings toggles ----------
    fun flipFirstSwitch(want: Boolean) {
        val sw = find { it.className?.contains("Switch") == true || it.className?.contains("Toggle") == true } ?: return
        if (sw.isChecked != want) click(sw)
    }

    // ---------- WhatsApp ----------
    private fun phoneFor(c: Context, name: String): String? = c.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        ?.filter { it.isDigit() || it == '+' }

    fun whatsappSend(c: Context, contact: String, msg: String) {
        val num = phoneFor(c, contact)?.removePrefix("+") ?: return
        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=${Uri.encode(msg)}")).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        later(2500) { clickId("com.whatsapp:id/send"); if (find { it.viewIdResourceName == "com.whatsapp:id/send" } != null) clickDesc("Send") }
    }
    fun whatsappCall(c: Context, contact: String) {
        val num = phoneFor(c, contact)?.removePrefix("+") ?: return
        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num")).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        later(2500) { clickDesc("Voice call") }
    }

    // ---------- Instagram: comment on the reel currently on screen ----------
    fun instagramComment(text: String) {
        clickDesc("Comment"); later(1200) { type(text); later(500) { clickDesc("Post") } }
    }

    // ---------- Screenshot for visual analysis (API 30+) → base64 JPEG ----------
    fun screenshot(cb: (String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) return cb(null)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                val o = ByteArrayOutputStream(); bmp?.compress(Bitmap.CompressFormat.JPEG, 60, o)
                cb(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))
            }
            override fun onFailure(e: Int) = cb(null)
        })
    }
}
