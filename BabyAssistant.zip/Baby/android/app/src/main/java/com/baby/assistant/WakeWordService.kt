package com.baby.assistant

import android.app.*
import android.content.*
import android.os.*
import android.speech.*

object BabyBus { var emit: ((String, Map<String, String>) -> Unit)? = null }

/** Foreground service: continuous hands-free wake-word + sleep handling. */
class WakeWordService : Service() {
    companion object { @Volatile var sleeping = false; @Volatile var micPaused = false
        @Volatile var instance: WakeWordService? = null }

    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var armedUntil = 0L          // after bare "Hey Baby", next utterance is the command
    private val sleepWords = listOf("so jao", "सो जाओ", "go to sleep", "ਸੌਂ ਜਾ", "झोप घे", "ઊંઘી જા", "ঘুমাও")

    private fun prefs() = getSharedPreferences("baby", MODE_PRIVATE)
    private fun name() = prefs().getString("name", "Baby")!!.lowercase()
    private fun lang() = prefs().getString("lang", "hi-IN")!!

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); instance = this; startForeground(1, notif()); loop() }
    override fun onDestroy() { instance = null; h.removeCallbacksAndMessages(null); rec?.destroy(); super.onDestroy() }

    private fun notif(): Notification {
        val ch = "baby"; val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Assistant", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, ch).setContentTitle("${prefs().getString("name", "Baby")} is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
    }

    fun emitState(s: String) = BabyBus.emit?.invoke("onState", mapOf("state" to s))
    fun setSleep(on: Boolean) { sleeping = on; emitState(if (on) "sleeping" else "listening") }

    /** Duty-cycle: awake = restart immediately; sleeping = short listen windows every 6s to save battery. */
    private fun loop() {
        h.post {
            if (micPaused) { h.postDelayed({ loop() }, 500); return@post }
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(b: Bundle?) { handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()); next() }
                    override fun onError(e: Int) = next()
                    override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}
                    override fun onEvent(t: Int, b: Bundle?) {}
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang())
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                })
            }
        }
    }
    private fun next() = h.postDelayed({ loop() }, if (sleeping) 6000L else 250L)

    private fun handle(raw: String?) {
        val t = raw?.lowercase()?.trim() ?: return
        val n = name()
        val wake = listOf("hey $n", "hay $n", "हे $n", "हे बेबी", "ए $n").firstOrNull { t.contains(it) }
        if (sleeping) { if (wake != null) { setSleep(false); BabyBus.emit?.invoke("onState", mapOf("state" to "listening")) }; return }
        if (sleepWords.any { t.contains(it) } && (wake != null || System.currentTimeMillis() < armedUntil)) {
            setSleep(true); BabyBus.emit?.invoke("onCommand", mapOf("text" to "go to sleep")); return
        }
        val armed = System.currentTimeMillis() < armedUntil
        if (wake != null) {
            val cmd = t.substringAfter(wake).trim()
            if (cmd.isEmpty()) { armedUntil = System.currentTimeMillis() + 8000; emitState("listening") }
            else BabyBus.emit?.invoke("onCommand", mapOf("text" to cmd))
        } else if (armed) { armedUntil = 0; BabyBus.emit?.invoke("onCommand", mapOf("text" to t)) }
    }
}
