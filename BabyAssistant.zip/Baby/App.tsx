import React, { useEffect, useState } from 'react';
import { StatusBar } from 'react-native';
import HomeScreen from './src/screens/HomeScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { DEFAULTS, Settings, loadSettings } from './src/store/settings';

export default function App() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [page, setPage] = useState<'home' | 'settings'>('home');
  useEffect(() => { loadSettings().then(setSettings); }, []);
  if (!settings) return null;
  return (<>
    <StatusBar barStyle="light-content" backgroundColor="#030A12" />
    {page === 'home'
      ? <HomeScreen settings={settings} openSettings={() => setPage('settings')} />
      : <SettingsScreen settings={settings} onSave={setSettings} onBack={() => setPage('home')} />}
  </>);
}
